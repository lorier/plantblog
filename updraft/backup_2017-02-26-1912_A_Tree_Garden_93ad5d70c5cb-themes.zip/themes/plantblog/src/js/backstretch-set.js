jQuery(function( $ ){
	$( '.before-content' ).backstretch( [KickstartBackStretchImg.src] );
});
